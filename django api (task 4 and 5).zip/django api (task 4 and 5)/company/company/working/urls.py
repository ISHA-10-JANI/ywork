from rest_framework.routers import DefaultRouter
from .views import departmentviewset, employessviewset, leaveapplicationviewset

router = DefaultRouter()
router.register('departments', departmentviewset)
router.register('employees', employessviewset)
router.register('leaves', leaveapplicationviewset)

urlpatterns = router.urls
