from django.db import models
from django.utils.translation import gettext_lazy as _

# Create your models here.

class department(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=122)

    def __str__(self):
        return self.name

class employess(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=122)
    basesalary = models.IntegerField()
    departmentid = models.ForeignKey(
        department,
        verbose_name=_("department"),
        on_delete=models.CASCADE
    )
    def __str__(self):
        return self.name
    
class leaveapplication(models.Model):
    employeeid = models.ForeignKey(
        employess,
        verbose_name=_("employess"),
        on_delete=models.CASCADE
    )
    month = models.CharField(max_length=10)
    year = models.CharField(max_length=10)
    leaves = models.IntegerField()



    def __str__(self):
        return self.name