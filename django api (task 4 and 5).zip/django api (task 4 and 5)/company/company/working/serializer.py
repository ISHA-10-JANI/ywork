from rest_framework import serializers
from .models import department,employess,leaveapplication

class Departmentserializer(serializers.ModelSerializer):
    class Meta:
        model = department 
        fields = '__all__'

class employessserializer(serializers.ModelSerializer):
    class Meta:
        model = employess 
        fields = '__all__'

class leaveapplicationserializer(serializers.ModelSerializer):
    class Meta:
        model = leaveapplication 
        fields = '__all__'
