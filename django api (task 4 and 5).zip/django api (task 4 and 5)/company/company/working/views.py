from django.shortcuts import render
from rest_framework import viewsets
from .models import department,employess,leaveapplication
from working.serializer import Departmentserializer,employessserializer,leaveapplicationserializer
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response


from django.db.models import F, FloatField, ExpressionWrapper, Max
# Create your views here.
class departmentviewset(viewsets.ModelViewSet):
    queryset = department.objects.all()
    serializer_class = Departmentserializer

    @action(detail=True, methods=['get'], url_path='high-earners')
    def high_earners(self, request, pk=None):
        top_salaries = employess.objects.filter(department_id=pk).order_by('-baseSalary').values_list('baseSalary', flat=True).distinct()[:3]
        top_emps = employess.objects.filter(department_id=pk, baseSalary__in=top_salaries)
        serializer = employessserializer(top_emps, many=True)
        return Response(serializer.data)


class employessviewset(viewsets.ModelViewSet):
    queryset = employess.objects.all()
    serializer_class = employessserializer

@action(detail=True, methods=['post'], url_path='set-basesalary')
def set_base_salary(self, request, pk=None):
        try:
            emp = self.get_object()
            salary = request.data.get('baseSalary')
            if salary is not None:
                emp.baseSalary = salary
                emp.save()
                return Response({"message": "Base salary updated."}, status=200)
            else:
                return Response({"error": "baseSalary field is required."}, status=400)
        except:
            return Response({"error": "Employee not found."}, status=404)
@action(detail=True, methods=['post'], url_path='calculate-payable-salary')
def calculate_payable_salary(self, request, pk=None):
        month = request.data.get('month')
        year = request.data.get('year')

        if not all([month, year]):
            return Response({"error": "Month and year are required."}, status=400)

        emp = self.get_object()
        leave = leaveapplication.objects.filter(employee=emp, month=month, year=year).first()
        leaves_taken = leave.leaves if leave else 0
        daily_salary = emp.baseSalary / 25
        payable = emp.baseSalary - (leaves_taken * daily_salary)

        return Response({
            "employee": emp.name,
            "month": month,
            "year": year,
            "leaves": leaves_taken,
            "payable_salary": round(payable, 2)
        })
@action(detail=False, methods=['get'], url_path='high-earners-by-month')
def high_earners_by_month(self, request):
        month = request.query_params.get('month')
        year = request.query_params.get('year')

        if not all([month, year]):
            return Response({"error": "month and year are required as query params"}, status=400)

        all_emps = employess.objects.all()
        salary_map = []

        for emp in all_emps:
            leave = leaveapplication.objects.filter(employee=emp, month=month, year=year).first()
            leave_days = leave.leaves if leave else 0
            daily = emp.baseSalary / 25
            payable = emp.baseSalary - (leave_days * daily)
            salary_map.append({'emp': emp, 'payable_salary': round(payable, 2)})

        top_salaries = sorted(set([s['payable_salary'] for s in salary_map]), reverse=True)[:3]
        high_earners = [s['emp'] for s in salary_map if s['payable_salary'] in top_salaries]

        serializer = employessserializer(high_earners, many=True)
        return Response(serializer.data)



class leaveapplicationviewset(viewsets.ModelViewSet):
    queryset = leaveapplication.objects.all()
    serializer_class = leaveapplicationserializer  
@action(detail=False, methods=['put'], url_path='increase-leaves')
def increase_leaves(self, request):
        emp_id = request.data.get('employeeId')
        month = request.data.get('month')
        year = request.data.get('year')
        leaves = int(request.data.get('leaves', 0))

        if not all([emp_id, month, year]):
            return Response({"error": "Missing fields."}, status=400)

        obj, created = leaveapplication.objects.get_or_create(
            employee_id=emp_id, month=month, year=year,
            defaults={'leaves': leaves}
        )
        if not created:
            obj.leaves += leaves
            obj.save()
        return Response({"message": "Leave count updated."}, status=200)    

